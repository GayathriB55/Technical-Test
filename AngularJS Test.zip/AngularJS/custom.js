angular.module('myModule', ['chart.js'])
			.config(function(ChartJsProvider) {
			})
			.controller("MixedChartCtrl",
			function ($scope) {
				$scope.colors = ['#707070', '#ed1c24'];
				$scope.labels = ['01/11/2013', '02/11/2013', '03/11/2013', '04/11/2013', '05/11/2013', '06/11/2013', '07/11/2013', '08/11/2013', '09/11/2013', '10/11/2013', '11/11/2013', '12/11/2013', '13/11/2013', '14/11/2013', '15/11/2013'];
				$scope.data = [
				  [2554532.56, 2250543.19, 2556617.06, 2528494.27, 2948224.32, 3369820.4, 3723651.54, 3958241.59, 3617832.81, 3798724.45, 3696158.89, 3884662.99, 3577774.62, 3670796.76, 3590039.23],
				  [1788172.792, 1597885.6649, 1840764.2832, 1845800.8171, 1916345.808, 2527365.3, 2829975.1704, 3047846.0243, 2821909.5918, 3000992.3155, 2956927.112, 3146577.0219, 2933775.1884, 3046761.3108, 3015632.9532]
				];
				$scope.datasetOverride = [
				  {
				    label: "Bar chart",
				    borderWidth: 0,
				    type: 'bar'
				  },
				  {
				    label: "Line chart",
				    borderWidth: 3,
				    fill: false,
				    type: 'line'
				  }
				];
				$scope.options = {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    },
                    type: 'time',
                    time: {
											unit: "month",
											displayFormats: { 'month': 'MMMM YYYY'}
										},
                    fontSize: 10
        			}],
                yAxes: [{
                    gridLines: {
                        display: true,
                        borderDash: [6, 4]
                    },
                    ticks: {
                    callback: function(label, index, labels) {
                        return label/1000000+'M';
				                }
				            },
                    position: "right",
                    fontSize: 18
        			}]
            },
            tooltips: {
		            mode: 'point',
		            backgroundColor: '#FFFFFF',
		            borderWidth: 1,
		            borderColor: '#707070',
		            displayColors: false,
		            bodyFontColor: '#ed1c24',
		            bodyFontSize: 18,
		            footerFontColor: '#707070',
		            footerFontSize: 18,
		            titleFontColor: '#cccccc',
		            titleFontSize: 10,
		            titleFontStyle: 'bold',

								callbacks: {
									title: function(tooltipItem, data) { return 'Exposure Trend';},
									label: function(tooltipItem, data) {
										var label = data.labels[tooltipItem.index];
										var datasetLabel = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
										return label + ',' + datasetLabel + '%';
									},
									footer: function(tooltipItem, data) { return 'Exposure';},
								}
					}
        };
		});
